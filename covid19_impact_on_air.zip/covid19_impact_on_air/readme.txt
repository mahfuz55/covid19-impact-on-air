1 . Tools needed
   a) Google colab
   b) fpprophet 
   c) matplotlib , pandas , numpy
   
2.  - Open each file in google colab and load the dataset in google colab from local machine.
    - please make sure the path of dataset in .pynb files are same as of actual path of dataset
    - run the program
    - In each file there are four output graphs are there two in favour of 'NOx' gas and two in      favour of 'SO2' gas.
    -first two graphs are of 'NOx' for before coid19 and during covid19 respectively .
    - Last two graphs are of 'SO2' for before covid and during covid19 respectively .
    - for each graph , future data points are forecasted .
    


